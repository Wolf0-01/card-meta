"use client";

import {
useEffect,
useMemo,
useState,
} from "react";

import type {
CardPreviewData,
} from "@/types/CardPreviewData";

import type {
DeckCard,
DeckCardInfo,
DeckZone,
} from "@/types/deck";

const STORAGE_KEY = "deck-builder";

const ZONE_LIMITS: Record<
DeckZone,
number

> = {
main: 30,
extra: 15,
side: 15,
};

const MAX_COPIES: Record<
DeckZone,
number

> = {
main: 3,
extra: 1,
side: 1,
};

export default function useDeckBuilder(
initialCards: DeckCard[] = []
) {
/*

* El estado inicial debe ser igual
* en el servidor y en el navegador.
*
* No leer localStorage aquí evita
* el error de hidratación.
  */
  const [
  cards,
  setCards,
  ] = useState<DeckCard[]>(
  initialCards
  );

/*

* Evita guardar el estado inicial vacío
* antes de terminar de cargar localStorage.
  */
  const [
  hasLoadedStorage,
  setHasLoadedStorage,
  ] = useState(false);

/*

* localStorage se lee solamente después
* de que React terminó la hidratación.
  */
  useEffect(() => {
  try {
  const saved =
  localStorage.getItem(
  STORAGE_KEY
  );

  if (saved) {
  const parsed:
  unknown =
  JSON.parse(saved);

  if (
  Array.isArray(
  parsed
  )
  ) {
  setCards(
  parsed as DeckCard[]
  );
  }
  }
  } catch {
  /*

  * Si localStorage contiene datos
  * inválidos, se mantiene initialCards.
    */
    } finally {
    setHasLoadedStorage(
    true
    );
    }
    }, []);

/*

* Guardar únicamente después de cargar
* el contenido existente.
  */
  useEffect(() => {
  if (
  !hasLoadedStorage
  ) {
  return;
  }


try {



  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(
      cards
    )
  );
} catch {
  /*
   * Ignorar errores de almacenamiento.
   */
}


}, [
cards,
hasLoadedStorage,
]);

function addCard(
card: CardPreviewData,
zone: DeckZone = "main"
) {
const deckCard:
DeckCardInfo = {
id:
card.id,


    ygoproId:
      card.ygoproId,

    name:
      card.name,

    description:
      card.description ??
      "",

    image:
      card.image,

    type:
      card.type,

    attribute:
      card.attribute,

    race:
      card.race,

    archetype:
      card.archetype,

    level:
      card.level,

    attack:
      card.attack,

    defense:
      card.defense,

    rarity:
      card.rarity,

    frameType:
      card.frameType,

    scale:
      card.scale,

    linkRating:
      card.linkRating,

    linkMarkers:
      Array.isArray(
        card.linkMarkers
      )
        ? card.linkMarkers
        : null,
  };

setCards(
  (current) => {
    const existing =
      current.find(
        (item) =>
          item.card.id ===
            deckCard.id &&
          item.zone ===
            zone
      );

    if (
      existing
    ) {
      const maxCopies =
        MAX_COPIES[
          zone
        ];

      if (
        existing.quantity >=
        maxCopies
      ) {
        return current;
      }

      return current.map(
        (item) =>
          item.card.id ===
            deckCard.id &&
          item.zone ===
            zone
            ? {
                ...item,

                quantity:
                  item.quantity +
                  1,
              }
            : item
      );
    }

    const zoneTotal =
      current
        .filter(
          (item) =>
            item.zone ===
            zone
        )
        .reduce(
          (
            total,
            item
          ) =>
            total +
            item.quantity,
          0
        );

    if (
      zoneTotal >=
      ZONE_LIMITS[
        zone
      ]
    ) {
      return current;
    }

    return [
      ...current,

      {
        id:
          `${zone}-${deckCard.id}`,

        quantity:
          1,

        zone,

        card:
          deckCard,
      },
    ];
  }
);


}

function removeCard(
cardId: number,
zone: DeckZone
) {
setCards(
(current) =>
current.flatMap(
(item) => {
if (
item.card.id !==
cardId ||
item.zone !==
zone
) {
return item;
}


        if (
          item.quantity >
          1
        ) {
          return {
            ...item,

            quantity:
              item.quantity -
              1,
          };
        }

        return [];
      }
    )
);


}

function setQuantity(
cardId: number,
zone: DeckZone,
quantity: number
) {
const safeQuantity =
Math.max(
0,
Math.min(
Math.floor(
quantity
),
MAX_COPIES[
zone
]
)
);


setCards(
  (current) => {
    if (
      safeQuantity ===
      0
    ) {
      return current.filter(
        (item) =>
          !(
            item.card.id ===
              cardId &&
            item.zone ===
              zone
          )
      );
    }

    return current.map(
      (item) =>
        item.card.id ===
          cardId &&
        item.zone ===
          zone
          ? {
              ...item,

              quantity:
                safeQuantity,
            }
          : item
    );
  }
);


}

function moveCard(
cardId: number,
from: DeckZone,
to: DeckZone
) {
if (
from === to
) {
return;
}


setCards(
  (current) => {
    const moving =
      current.find(
        (item) =>
          item.card.id ===
            cardId &&
          item.zone ===
            from
      );

    if (
      !moving
    ) {
      return current;
    }

    const target =
      current.find(
        (item) =>
          item.card.id ===
            cardId &&
          item.zone ===
            to
      );

    const targetTotal =
      current
        .filter(
          (item) =>
            item.zone ===
            to
        )
        .reduce(
          (
            total,
            item
          ) =>
            total +
            item.quantity,
          0
        );

    if (
      !target &&
      targetTotal +
        moving.quantity >
        ZONE_LIMITS[
          to
        ]
    ) {
      return current;
    }

    const nextQuantity =
      target
        ? target.quantity +
          moving.quantity
        : moving.quantity;

    if (
      nextQuantity >
      MAX_COPIES[
        to
      ]
    ) {
      return current;
    }

    const withoutMoving =
      current.filter(
        (item) =>
          !(
            item.card.id ===
              cardId &&
            item.zone ===
              from
          )
      );

    if (
      target
    ) {
      return withoutMoving.map(
        (item) =>
          item.card.id ===
            cardId &&
          item.zone ===
            to
            ? {
                ...item,

                quantity:
                  nextQuantity,
              }
            : item
      );
    }

    return withoutMoving.map(
      (item) =>
        item.card.id ===
          cardId &&
        item.zone ===
          from
          ? {
              ...item,

              zone:
                to,

              id:
                `${to}-${cardId}`,
            }
          : item
    );
  }
);


}

function clearDeck() {
setCards(
[]
);
}

const stats =
useMemo(() => {
const main =
cards
.filter(
(card) =>
card.zone ===
"main"
)
.reduce(
(
total,
card
) =>
total +
card.quantity,
0
);


  const extra =
    cards
      .filter(
        (card) =>
          card.zone ===
          "extra"
      )
      .reduce(
        (
          total,
          card
        ) =>
          total +
          card.quantity,
        0
      );

  const side =
    cards
      .filter(
        (card) =>
          card.zone ===
          "side"
      )
      .reduce(
        (
          total,
          card
        ) =>
          total +
          card.quantity,
        0
      );

  return {
    main,

    extra,

    side,

    total:
      main +
      extra +
      side,
  };
}, [
  cards,
]);


return {
cards,


stats,

setCards,

addCard,

removeCard,

setQuantity,

moveCard,

clearDeck,

hasLoadedStorage,


};
}
