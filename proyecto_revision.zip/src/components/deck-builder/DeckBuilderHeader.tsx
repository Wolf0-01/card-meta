"use client";

import Button from "@/components/ui/Button";

import {
  BuilderDeck,
  BuilderDeckStats,
} from "@/types/deck-builder";

interface DeckBuilderHeaderProps {
  deck: BuilderDeck;

  stats: BuilderDeckStats;

  onSave?: () => void;

  onImport?: () => void;

  onExport?: () => void;
}

export default function DeckBuilderHeader({
  deck,
  stats,
  onSave,
  onImport,
  onExport,
}: DeckBuilderHeaderProps) {
  return (
    <header
      className="
        rounded-2xl
        border
        border-zinc-800
        bg-zinc-900
        p-6
      "
    >
      <div
        className="
          flex
          flex-col
          gap-6
          lg:flex-row
          lg:items-center
          lg:justify-between
        "
      >
        <div>
          <h1
            className="
              text-3xl
              font-black
              text-white
            "
          >
            {deck.name}
          </h1>

          {deck.description && (
            <p
              className="
                mt-2
                text-zinc-400
              "
            >
              {deck.description}
            </p>
          )}

          <div
            className="
              mt-5
              flex
              flex-wrap
              gap-3
            "
          >
            {deck.archetype && (
              <span
                className="
                  rounded-full
                  bg-blue-500/20
                  px-3
                  py-1
                  text-sm
                  text-blue-300
                "
              >
                {deck.archetype}
              </span>
            )}

            {deck.skill && (
              <span
                className="
                  rounded-full
                  bg-purple-500/20
                  px-3
                  py-1
                  text-sm
                  text-purple-300
                "
              >
                {deck.skill}
              </span>
            )}

            {deck.format && (
              <span
                className="
                  rounded-full
                  bg-zinc-800
                  px-3
                  py-1
                  text-sm
                "
              >
                {deck.format}
              </span>
            )}
          </div>
        </div>

        <div
          className="
            flex
            flex-col
            gap-4
            lg:items-end
          "
        >
          <div
            className="
              flex
              flex-wrap
              gap-4
              text-sm
              text-zinc-400
            "
          >
            <span>
              Main:{" "}
              <strong>
                {stats.main}/30
              </strong>
            </span>

            <span>
              Extra:{" "}
              <strong>
                {stats.extra}/8
              </strong>
            </span>

            <span>
              Side:{" "}
              <strong>
                {stats.side}/10
              </strong>
            </span>

            <span>
              Total:{" "}
              <strong>
                {stats.total}
              </strong>
            </span>
          </div>

          <div
            className="
              flex
              flex-wrap
              gap-3
            "
          >
            <Button
              variant="secondary"
              onClick={onImport}
            >
              Import
            </Button>

            <Button
              variant="secondary"
              onClick={onExport}
            >
              Export
            </Button>

            <Button
              onClick={onSave}
            >
              Save Deck
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}