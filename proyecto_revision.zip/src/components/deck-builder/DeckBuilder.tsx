"use client";

import CardBrowser from "@/components/cards/CardBrowser";

import type {
CardPreviewData,
} from "@/types/CardPreviewData";

import type {
BuilderDeck,
BuilderDeckStats,
DeckZone,
} from "@/types/deck-builder";

import DeckBuilderHeader from "./DeckBuilderHeader";
import DeckBuilderToolbar from "./DeckBuilderToolbar";
import DeckZones from "./DeckZones/DeckZones";

interface DeckBuilderProps {
deck: BuilderDeck;

stats: BuilderDeckStats;

availableCards: CardPreviewData[];

addCard: (
card: CardPreviewData
) => void;

removeCard: (
cardId: number,
zone: DeckZone
) => void;

moveCard: (
cardId: number,
from: DeckZone,
to: DeckZone
) => void;

setQuantity: (
cardId: number,
zone: DeckZone,
quantity: number
) => void;

clearDeck: () => void;
}

export default function DeckBuilder({
deck,
stats,
availableCards,
addCard,
removeCard,
moveCard,
setQuantity,
clearDeck,
}: DeckBuilderProps) {
return ( <section className="space-y-6"> <DeckBuilderHeader
     deck={deck}
     stats={stats}
   />


  <DeckBuilderToolbar
    onClear={clearDeck}
  />

  <div
    className="
      grid
      gap-6
      xl:grid-cols-[2fr_1fr]
    "
  >
    <DeckZones
      cards={deck.cards}
      onRemoveCard={removeCard}
      onMoveCard={moveCard}
      onSetQuantity={setQuantity}
    />

    <CardBrowser
      cards={availableCards}
      onAddCard={addCard}
    />
  </div>
</section>


);
}
