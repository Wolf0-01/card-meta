"use client";


import {
  cardFilterConfig
} from "@/config/cardFilterConfig";


import {
  CardFiltersState
} from "@/types/card-filters";



interface Props {

  filters:CardFiltersState;

  setFilters:React.Dispatch<
    React.SetStateAction<CardFiltersState>
  >;

}


const inputClass = `

bg-zinc-800

border

border-zinc-700

rounded-xl

p-3

text-sm

`;






export default function CardFilters({

  filters,

  setFilters

}:Props){





function updateFilter(

  key:keyof CardFiltersState,

  value:string

){


  setFilters(prev=>({

    ...prev,

    [key]:value

  }));


}







return (


<div

className="

bg-zinc-900

border

border-zinc-700

rounded-xl

p-4

grid

grid-cols-2

md:grid-cols-4

gap-3

"

>


{/* BUSQUEDA */}

<input


value={
filters.search ?? ""
}


onChange={e=>

updateFilter(

"search",

e.target.value

)

}


placeholder="Buscar carta..."


className={inputClass}


/>







{/* SELECT DINAMICOS */}

{

cardFilterConfig.map(filter=>(


<select


key={filter.key}


value={

filters[
filter.key as keyof CardFiltersState
] ?? ""

}



onChange={e=>

updateFilter(

filter.key as keyof CardFiltersState,

e.target.value

)

}


className={inputClass}


>


<option value="">

{filter.label}

</option>



{

filter.options.map(option=>(


<option

key={option}

value={option}

>

{option}

</option>


))

}



</select>


))

}







{/* ARCHETYPE */}

<input


value={
filters.archetype ?? ""
}


onChange={e=>

updateFilter(

"archetype",

e.target.value

)

}


placeholder="Arquetipo"


className={inputClass}


/>








{/* ATK MIN */}

<input

type="number"


value={
filters.minAtk ?? ""
}


onChange={e=>

updateFilter(

"minAtk",

e.target.value

)

}


placeholder="ATK mínimo"


className={inputClass}


/>








{/* ATK MAX */}

<input

type="number"


value={
filters.maxAtk ?? ""
}


onChange={e=>

updateFilter(

"maxAtk",

e.target.value

)

}


placeholder="ATK máximo"


className={inputClass}


/>








{/* DEF MIN */}

<input

type="number"


value={
filters.minDef ?? ""
}


onChange={e=>

updateFilter(

"minDef",

e.target.value

)

}


placeholder="DEF mínimo"


className={inputClass}


/>








{/* DEF MAX */}

<input

type="number"


value={
filters.maxDef ?? ""
}


onChange={e=>

updateFilter(

"maxDef",

e.target.value

)

}


placeholder="DEF máximo"


className={inputClass}


/>



</div>


);


}