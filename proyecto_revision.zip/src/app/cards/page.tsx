import CardPageClient from "@/components/cards/CardPageClient";

import { queryCards } from "@/lib/queryCards";

import type { Card } from "@/types/card";

interface CardsPageProps {
  searchParams: Promise<{
    page?: string;
    search?: string;
    type?: string;
    attribute?: string;
    level?: string;
    archetype?: string;
  }>;
}

export default async function CardsPage({
  searchParams,
}: CardsPageProps) {
  const params = await searchParams;

  const page = Number(params.page ?? 1);

  const result = await queryCards({
    search: params.search,
    type: params.type,
    attribute: params.attribute,
    level: params.level
      ? Number(params.level)
      : undefined,
    archetype: params.archetype,
    page,
  });

  const cards: Card[] = result.cards.map(
    (card) => ({
      ...card,

      linkMarkers:
        card.linkMarkers as Card["linkMarkers"],
    })
  );

  return (
    <main
      className="
        min-h-screen
        bg-zinc-950
        px-4
        py-6
        text-white
      "
    >
      <div
        className="
          mx-auto
          max-w-7xl
        "
      >
        <CardPageClient
          cards={cards}
        />
      </div>
    </main>
  );
}